﻿Write-Host "Installing translations..." -ForegroundColor Green

# Copy files
Copy-Item "app_*.arb" -Destination "lib/l10n/" -Force

Write-Host "✅ Translations installed!" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:"
Write-Host "1. Run: dart run lib/tools/check_arb_keys.dart"
Write-Host "2. Run: flutter gen-l10n"
Write-Host "3. Test: flutter run"
Write-Host ""
Read-Host "Press Enter to exit"
